# EdgeQ - Automation Framework

## Getting started 

### Installation Requirements
1.	Python 3.x
2.  PyCharm IDE(Recommended for code edit)

## Install Python
To install python, go to python official site − https://www.python.org/downloads/ and download the latest version or the prior version of python as per your operating system (Windows, Linux/Unix, Mac, and OS X) you are going to use.

Before you download python, it is recommended you check your system if python is already present by running the following command in the command line −
#### windows Installation
    python -version

### Setting Path for Windows
Click on Windows icon on keyboard and search Edit environment variables for your account it will display on search option Click it will open than click on Advanced System setting.

Click on Environment Variables button, Select the Variable Path and click the Edit button.
Get the path where python is installed and add the same to Variable value, click ok to save variable.

Once this is done, you can check if python is installed from any path or directory as shown below –

### Install PIP
Now, we will check for the next step, which is pip installation for python. PIP is a package manager to install modules for python.
PIP gets installed along with python, and you can check the same in command line as follows −
#### In windows
    pip –version

## Install PYCHARM IDE(Recommended)
To install pycharm IDE, go to Jetbrains official site − https://www.jetbrains.com/pycharm/download/other.html and download the Pycharm community version or the prior version of IDE as per your operating system (Windows, linux)

After downloading the IDE please install and make tool ready 

## Automation CODE TO YOUR LOCAL MACHINE

Get the code from Automation team or repository and place any location in your local system

Open Pycharm IDE and Open the Project location and attach to IDE

### Install Packages
In pycharm IDE will get recommendation to install the packages or through command line we need to execute the requirements.txt file located in project folder

    pip -r "file_path/requiremnts.txt"

After installing all python libraries your framework setup and code ready to execute

# Automating Test cases Results in TestLink
To update the results in testlink we need to update the details in testlink_config.ini file located in Config folder

#### Details to be added or updated in config file
Open the testlink_config.ini add or update below sections data

[Server]

URL = http://192.168.8.39/lib/api/xmlrpc/v1/xmlrpc.php

DevKey = 4e072926c8754272776af9bd244bd7e5

#### In above server details need to updated Devkey with respect of testlink user
To get dev key follow the steps
1. Open Testlink URL and Login with your credentials
2. After login go to My settings
3. Go to API interface Click on Generate a new key 
4. Display the Personal API access Key 
5. Copy key and place it ti Devkey value in config file


[TestLinkPlan]

Testplanid = 339

Buildname=GP3_PH1_RC3.5

[TestCases]
EQ-38 = EQ-38,f,Build Achieved
EQ-39 = EQ-39,p,Build Success
EQ-40 = EQ-40,f,Build failed

Test cases data in the format of testcaseexternalid,status,notes

Status

    p = Pass f = Fail
Note:
No spaces for Test cases values should be separated with only (,) currently we allowed only three parameters 

After updated data successfully in .ini file 

Run the file Testlink_Results_Update_Executor.py file located in Scripts Folder

# Triggering the Testcases in Simnovator App
Run Test cases via simnovus tool update test cases list in simnovus_config.ini file located in Config folder

#### Details to be added or updated in config file
Open the simnovus_config.ini add or update below sections data

[Simnovus]

URL = http://192.168.2.85/#/login

IP = 192.168.2.85

[Credentials]

username = user@simnovus.com

password = simnovus

[TestCases]
#### Add Test case name and duration value with separation of (,) no space include before and after ,
Test_32UE_BIDI = Test_32UE_BIDI,20

Test_1UE_BIDI = Test_1UE_BIDI,20

Test_1UE_DL = Test_1UE_DL,25

Test_1UE_UL = Test_1UE_UL,30

Test cases data in the format of Test_case_name,execution_duration

After updated data successfully in .ini file 

Run the file Simnovus_Executor.py file located in Scripts Folder