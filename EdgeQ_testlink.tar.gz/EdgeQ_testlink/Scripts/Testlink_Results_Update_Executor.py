from Library.UTILS.Testlink_Utils import Testlink_Utils


class Testlink_Results_Update_Executor:

    def __init__(self):
        self.testlink_utils = Testlink_Utils()

    def update_results(self):
        self.testlink_utils.report_results()


if __name__ == "__main__":
    tru = Testlink_Results_Update_Executor()
    tru.update_results()
