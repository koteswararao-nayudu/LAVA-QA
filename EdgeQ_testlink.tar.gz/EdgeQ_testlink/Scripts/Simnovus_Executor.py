import time
from pathlib import Path

from Library.UTILS.webGUIcore import WebGuiCore
from selenium.webdriver.common.by import By
import configparser
from datetime import datetime


class Simnovus_Executor:

    def __init__(self):
        self.BROWSER = WebGuiCore("chrome")
        self.config = configparser.ConfigParser()
        self.config.sections()
        simnovus_config_path = Path(__file__).parent.parent / 'Config/simnovus_config.ini'
        self.config.read(simnovus_config_path)

    def login(self):
        try:
            print("Launching Simnovus URL and Trying to login with Simnovus Credentials: username:" +
                  self.config['Credentials']['username'] + " and password:" + self.config['Credentials']['password'])
            self.BROWSER.get_url(self.config['Simnovus']['URL'])
            self.BROWSER.send_text("//input[@id = 'username']", By.XPATH, self.config['Credentials']['username'])
            self.BROWSER.send_text("//input[@formcontrolname = 'password']", By.XPATH,
                                   self.config['Credentials']['password'])
            self.BROWSER.browser_click("//button[contains(., 'Log In')]", By.XPATH)
        except Exception as err:
            print("URL fetch failed returning False", err)
            self.BROWSER.quit_browser()

    def logout(self):
        try:
            print("Logging out the application")
            self.BROWSER.browser_click("//img[@alt = 'Profile Image']", By.XPATH)
            self.BROWSER.browser_click("//a[3][contains(., 'Logout')]", By.XPATH)
        except Exception as err:
            print("Logging out the application failed", err)
            self.BROWSER.quit_browser()

    def start(self):
        self.BROWSER.browser_click("//img[@title = 'Start']", By.XPATH)

    def edit(self):
        self.BROWSER.browser_click("//img[@title = 'View/Edit']", By.XPATH)
        time.sleep(2)
        self.BROWSER.browser_click("//div[1]/div[1]/div/div/a[1]", By.XPATH)

    def test_duration(self, duration, tc_name):
        try:
            time.sleep(int(duration) - 10)
            self.BROWSER.browser_click("//app-sidebar/div/div[2]/span[contains(.,'Global Stats')]", By.XPATH)
            time.sleep(2)
            self.BROWSER.take_screen_shot(tc_name)
            time.sleep(2)
            self.BROWSER.browser_click("//app-sidebar/div/div[4]/span[contains(.,'UE Stats')]", By.XPATH)
            time.sleep(2)
            self.BROWSER.take_screen_shot(tc_name)
            time.sleep(4)
            self.BROWSER.browser_click("//app-sidebar/div/div[1]/span[contains(.,'Test Cases')]", By.XPATH)
        except Exception as error:
            print("Test_duration functionality failed", error)

    def trigger_test(self):
        try:
            sections_data = [option for option in self.config['TestCases']]
            for test_cases in sections_data:
                values = self.config.get('TestCases', test_cases)
                tc = values.split(",")[0]
                duration = values.split(",")[1]
                self.BROWSER.send_text("//input[@id = 'searchConfig']", By.XPATH, tc)
                self.BROWSER.browser_click("//tbody/tr[1]/td[1]/label/span", By.XPATH)
                time.sleep(1)
                self.edit()
                print(tc, "triggered start time: ", datetime.now())
                self.test_duration(duration, tc)
                print(tc, "finished end time: ", datetime.now())
        except Exception as error:
            print(tc, "triggering failed", error)


if __name__ == "__main__":
    simtrigger = Simnovus_Executor()
    simtrigger.login()
    simtrigger.trigger_test()
    simtrigger.logout()
