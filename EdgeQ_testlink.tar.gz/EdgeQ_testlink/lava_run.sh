#!/usr/bin/sh

jobid=`lavacli --uri http://admin:es3bkjwhjo04oazzl0zqhl7zfr2n8wf1eg3zl246o9gspyyi2pczdsotmufgyc00yzkjuz6o0pl28mymjz7he980artaysb7hj4h4r5tia1u2f3y3ecf94ys1ye32ns0@192.168.3.198/RPC2/ jobs submit   /lab-nfs/koti/tmp/EdgeQ_testlink/testlink_demo.yaml`
echo "lava_jobid =$jobid"

#jobid=6898
executionstatus=""
while [ True ]
do
	state=`lavacli --uri http://admin:es3bkjwhjo04oazzl0zqhl7zfr2n8wf1eg3zl246o9gspyyi2pczdsotmufgyc00yzkjuz6o0pl28mymjz7he980artaysb7hj4h4r5tia1u2f3y3ecf94ys1ye32ns0@192.168.3.198/RPC2/ jobs show $jobid | grep state | grep Finished | awk -F ': ' '{print $2}'`
	if [ "$state" = "Finished" ]
	then
		result=`lavacli --uri http://admin:es3bkjwhjo04oazzl0zqhl7zfr2n8wf1eg3zl246o9gspyyi2pczdsotmufgyc00yzkjuz6o0pl28mymjz7he980artaysb7hj4h4r5tia1u2f3y3ecf94ys1ye32ns0@192.168.3.198/RPC2 results $jobid | grep -iv "* lava." | grep -v "Results:" | awk -F "_"  '{print $2}' | awk -F "." '{print $2}' | awk -F " " '{print $2}' | awk -F "[" '{print $2}' | awk -F "]" '{print $1}' `
		echo "result=$result"
		if [ "$result" = "pass" ]
		then
			testlinkresult="p"
		else
			testlinkresult="f"
		fi
		cd /lab-nfs/koti/tmp/EdgeQ_testlink
		cp /lab-nfs/koti/tmp/EdgeQ_testlink/Config/testlink_config_generic.ini /lab-nfs/koti/tmp/EdgeQ_testlink/Config/testlink_config.ini
		export PYTHONPATH="${PYTHONPATH}:/home/equser/Ravindra/EdgeQ_testlink"
		sed -i "s/RESULT/$testlinkresult/g" /lab-nfs/koti/tmp/EdgeQ_testlink/Config/testlink_config.ini
		/usr/bin/python3 Scripts/Testlink_Results_Update_Executor.py
		executionstatus="completed"
	fi
	sleep 5
	job_status=`lavacli --uri http://admin:es3bkjwhjo04oazzl0zqhl7zfr2n8wf1eg3zl246o9gspyyi2pczdsotmufgyc00yzkjuz6o0pl28mymjz7he980artaysb7hj4h4r5tia1u2f3y3ecf94ys1ye32ns0@192.168.3.198/RPC2/ jobs show $jobid | grep state`
	echo "lava_job_$job_status"
	if [ "$executionstatus" = "completed" ]
	then
		break;
	fi
done
