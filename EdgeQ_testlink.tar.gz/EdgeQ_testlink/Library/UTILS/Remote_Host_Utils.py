import os
import sys
from Library.PARSER.SSH_Command_Parser import SSH_Command_Parser
from Library.PARSER.CONFIG_Parser import CONFIG_Parser


class Remote_Host_Utils:

    def __init__(self):
        self.ssh = SSH_Command_Parser()
        self.config = CONFIG_Parser()
        self.ip = self.config.get_value("HOST", "IP")
        self.username = self.config.get_value("HOST", "UserName")
        self.password = self.config.get_value("HOST", "Password")

    def file_download(self, remote_path):
        """
            This function is get any formation of file from remote path over the remote host connection
            :param remote_path: parameter required to pass remote file path
            :return: return true if executes else false
        """
        try:
            filename = remote_path.split('/')
            local_Path = os.getcwd().replace("\\", "/") + '/' + "CU_KPI_Excel_File.xlsx"
            if self.ssh.connect(self.ip, self.username, self.password):
                ftp_client = self.ssh.client.open_sftp()
                print(f"downloading {filename[-1].upper()} file\n")
                self.ssh.client.exec_command("chmod -R 777 " + remote_path)
                ftp_client.get(remote_path, local_Path)
                print(f"{filename[-1].upper()} file Downloaded successfully\n")
                ftp_client.close()
        except Exception as e:
            raise Exception(f"Error while connecting to machine", e)


rhu = Remote_Host_Utils()
rhu.file_download(remote_path=sys.argv[1])
