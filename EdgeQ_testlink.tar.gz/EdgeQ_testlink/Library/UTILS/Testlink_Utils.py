from configparser import ConfigParser
from pathlib import Path
from Library.PARSER.CONFIG_Parser import CONFIG_Parser

import testlink


class Testlink_Utils:
    """
        This Class library contains Test link utils and wrappers of test link functions
        def connect
        def get_testcase_details
        def get_all_testcases
        def report_results
        def get_last_execution_results
    """

    def __init__(self):
        self.tls = None
        self.conf = CONFIG_Parser()
        self.config = ConfigParser()
        testlink_config_path = Path(__file__).parent.parent.parent / 'Config/testlink_config.ini'
        self.config.read(testlink_config_path)
        self.config.sections()
        self.URL = self.config['Server']['URL']
        self.DevKey = self.config['Server']['DevKey']
        self.test_plan_id = self.config['TestLinkPlan']['Testplanid']
        self.build_name = self.config['TestLinkPlan']['Buildname']
        self.TestlinkHelper = testlink.TestLinkHelper()
        self.TestlinkAPIClient = testlink.TestlinkAPIClient

    def connect(self):
        """
            This Function will connect the Test-link Server api's and return the connection and server details
            :return: return true if executes else false
        """
        try:
            self.tls = self.TestlinkHelper.connect(self.TestlinkAPIClient)
            self.tls.__init__(self.URL, self.DevKey)
            print(self.tls)
            return self.tls
        except Exception as error:
            print("Test-link Sever connection failure Error", error)

    def get_testcase_details(self, full_tc_external_id):
        """
            This function will return the test case of Test case_id, Name, TestSuite_id, status and execution_type
            :param tc_id: parameter required to pass test case id
            :return: return true if executes else false
        """
        try:
            if self.connect():
                tc_info = self.tls.getTestCase(None, testcaseexternalid=full_tc_external_id)
                print(tc_info)
                data = []
                for i in tc_info:
                    data.extend([i["testcase_id"], i["name"], i['testsuite_id'], i['status'], i['execution_type']])
                    return data
        except Exception as error:
            print("Failed to fetch the test case details", error)

    def report_results(self):
        """
            This function will connect the test link and update the test case results status
            :return: return true if executes else false
        """
        try:
            sections_data = [option for option in self.config['TestCases']]
            for test_cases in sections_data:
                values = self.config.get('TestCases', test_cases)
                tc_id = values.split(",")[0]
                status = values.split(",")[1]
                notes = values.split(",")[2]
                if self.connect():
                    get_tsd = self.get_testcase_details(tc_id)
                    self.tls.reportTCResult(testcaseid=get_tsd[0], testplanid=self.test_plan_id,
                                            buildname=self.build_name, status=status,
                                            notes=notes)
                print("Results Updated Successfully")
        except Exception as error:
            print("Updating results in testlink is failed ", error)

    def get_last_execution_result(self, etc_id):
        """
            This function will fetch the last execution results of test case in test link
            :param etc_id: parameter required to pass external test case id
            :return: return true if executes else false
        """
        try:
            if self.connect():
                get_tsd = self.get_testcase_details(etc_id)
                results = self.tls.getLastExecutionResult(self.test_plan_id, testcaseid=get_tsd[0])
                return results
        except Exception as error:
            print("Not able to fetch the results ", error)

    def upload_files(self, file_path=None):
        """
            This function will upload the attachments to testlink test cases
            :return: return true if executes else false
        """
        try:
            if self.connect():
                a_file_obj = open("Sample-png-image-200kb.png", encoding="utf8", errors="ignore")
                self.tls.uploadExecutionAttachment(a_file_obj, '293', 'Attachment Title',
                                                   'Attachment Description', file_type='image/png')
        except Exception as error:
            print("Failed to upload the file", error)
