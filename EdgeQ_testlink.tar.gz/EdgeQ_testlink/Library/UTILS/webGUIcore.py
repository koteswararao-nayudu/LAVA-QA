import os
import time
from datetime import datetime
from pathlib import Path

from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait


class WebGuiCore:

    def __init__(self, browser):
        """
            This is the constructor which will create an operable driver for
            the automation
            :param browser: The browser that is required
        """
        self.path = None
        self.timestamp = None
        self.driver_path = None
        self.datetime = datetime.now()
        if browser.lower() == "chrome":
            self.driver = self.__create_chromedriver()
        else:
            print("Browser Name is not available")
        self.root_window_handle = self.get_current_window_handle
        self.counter = 0

    def get_chrome(self):
        """
            This function will download the Chrome browser and provide the path
            :return: return driver_path if executes else false
        """
        self.driver_path = ChromeDriverManager().install()
        return self.driver_path

    def __create_chromedriver(self):
        """
            This private function will open the Chrome browser

            :return: return true if executes else false
        """
        chrome_path = self.get_chrome()
        chrome_options = Options()
        chrome_options.add_argument('--no-sandbox')
        # chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-dev-shm-usage')
        service = Service(executable_path=chrome_path)
        driver = webdriver.Chrome(service=service)
        driver.maximize_window()
        return driver

    def get_url(self, url):
        """
            This function is used for  getting the desired URL
            :param url: str URL is the URL that need to be fetched
        """
        self.driver.get(url)

    def close_browser(self):
        """
            This function is to close the browser
        """
        self.driver.close()

    def quit_browser(self):
        """
            This function is to close the browser
        """
        self.driver.quit()

    def browser_back(self):
        """
            This function is to simulate the back button of the browser.
        """
        self.driver.back()

    def browser_forward(self):
        """
            This function is to simulate the forward button of the browser.
        """
        self.driver.forward()

    def browser_click(self, locator, type):
        """
            This function performs a click operation in a browser
        """
        self.driver.implicitly_wait(5)
        self.__get_webElement(locator, type).click()

    def take_screen_shot(self, test_file):
        """
            This function is used to take the screenshot of the current window
            :param test_file: the file which is executed at the moment
        """
        self.path = os.path.abspath('../Screenshots/')
        self.timestamp = datetime.timestamp(self.datetime)
        self.counter = self.counter + 1
        self.driver.save_screenshot(self.path+ "/" + test_file+
                                    "_" + str(self.counter) + "_" + str(self.timestamp)+ ".png")

    def scroll_to_element(self, locator, type):
        """
            This function is used to scroll down current window
            :param locator: the locator used to locate the element
            :param type: the tpe of locator used
        """
        # self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        action_chains = ActionChains(self.driver)
        action_chains.move_to_element(self.__get_webElement(locator, type)).perform()
        time.sleep(5)

    def get_current_window_handle(self):
        """
            This function is to get the current window handle of the web browser.
            :return: current window handle
        """
        return self.driver.current_window_handle

    def __get_webElement(self, locator, type):
        """
            This function obtains the web element for performing operations
        """
        if type == By.XPATH:
            return self.driver.find_element(By.XPATH, locator)
        elif type == By.ID:
            return self.driver.find_element(By.ID(locator))
        elif type == By.CLASS_NAME:
            return self.driver.find_element(By.CLASS_NAME(locator))
        elif type == By.CSS_SELECTOR:
            return self.driver.find_element(By.CSS_SELECTOR(locator))
        elif type == By.LINK_TEXT:
            return self.driver.find_element(By.LINK_TEXT(locator))
        elif type == By.PARTIAL_LINK_TEXT:
            return self.driver.find_element(By.PARTIAL_LINK_TEXT(locator))
        elif type == By.NAME:
            return self.driver.find_element(By.NAME(locator))
        elif type == By.TAG_NAME:
            return self.driver.find_element(By.TAG_NAME(locator))
        else:
            raise Exception(" The Identifier not available:" + str(type))

    def send_text(self, locator, type, text):
        """
            This performs the action of sending text to a text box or a
            web-element that can accept text
            :param locator: the locator used to locate the element
            :param type: the tpe of locator used
            :param text: the text that has to be supplied in
        """
        self.__get_webElement(locator, type).clear()
        self.__get_webElement(locator, type).send_keys(text)

    def file_upload(self, locator, type, text):
        """
            This performs the action of sending text to a text box or a
            web-element that can accept text
            :param locator: the locator used to locate the element
            :param type: the tpe of locator used
            :param text: the text that has to be supplied in
        """
        self.__get_webElement(locator, type).send_keys(text)

    def find_element(self, locator, type):
        self.__get_webElement(locator, type)

    def get_text(self, locator, type):
        """
            This performs the action of getting text to a text box or a
            web-element
            :param locator: the locator used to locate the element
            :param type: the tpe of locator used
        """
        return self.__get_webElement(locator, type).text

    def get_attribute_value(self, locator, type):
        return self.__get_webElement(locator, type).get_attribute("value")

    def sendKeys(self, locator, type, data, driver):
        WebDriverWait(driver=driver, timeout=120).until(
            lambda x: x.execute_script("return document.readyState ==='complete'"))
        self.__get_webElement(locator, type).send_keys(data)

    def mouseHoverAction(self, locator, type):
        element_to_hover_over = self.__get_webElement(locator, type)
        hover = ActionChains(self.driver).move_to_element(element_to_hover_over)
        hover.perform()