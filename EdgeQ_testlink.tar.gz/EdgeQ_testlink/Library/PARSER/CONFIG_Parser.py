import configparser
import os


class CONFIG_Parser:

    def get_value(self, section, key):
        """
            This Function will return the config values from ini file
            :param section: parameter required to pass section name
            :param key: parameter required to pass key name
            :return: return to true if executes else fail
        """
        locator = configparser.ConfigParser()
        locator.read(os.path.abspath('../../Config/config.ini'))
        ret_locator = locator.get(section, key)
        return ret_locator

    def get_sections(self):
        locator = configparser.ConfigParser()
        locator.read(os.path.abspath('../../Config/testlink_config.ini'))
        sections_data = [option for option in locator['TestCases']]
        for test_cases in sections_data:
            values = locator.get('TestCases', test_cases)
            print (values)
            tc_id = values.split(",")[0]
            status = values.split(",")[1]
            notes = values.split(",")[2]
            print(tc_id, status, notes)

#
# cfg = CONFIG_Parser()
# cfg.get_sections()
