__author__ = "Ravindra"
"""
    This file connects Remote host machine via SSH and download the xlsx file to your local 
    need to pass excel file location parameters as file output
"""

from socket import socket
import paramiko
from Library.PARSER.CONFIG_Parser import CONFIG_Parser


class SSH_Command_Parser:
    """
        This is a user written keyword library.
        These libraries can be pretty handy for ssh commands and connections
        However, they are less simple in syntax and less transparent in test protocols.

        class SSH_Command_Parser:
            def connect
            def run_command
    """

    def __init__(self):
        self.client = None
        self.ssh_output = None
        self.ssh_error = None
        self.config = CONFIG_Parser()
        self.ip = self.config.get_value("HOST", "IP")
        self.username = self.config.get_value("HOST", "UserName")
        self.password = self.config.get_value("HOST", "Password")

    def connect(self, ip, user, password):
        """
            This function connect to the remote host machine via paramiko
            :return: return true if connected else false
        """
        try:
            print("Establishing Remote Machine connection on ")
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            print("connecting...")
            self.client.connect(hostname=ip, username=user, password=password,
                                allow_agent=True, look_for_keys=True)
            print("Connected Successfully")
        except paramiko.BadHostKeyException:
            raise Exception('BadHostKeyException on')
        except paramiko.AuthenticationException:
            raise Exception("Authentication failed, please verify your credentials")
        except paramiko.SSHException as sshException:
            raise Exception("Could not establish SSH connection: %s" % sshException)
        except Exception as error:
            print("PYTHON SAYS:", error)
            result_flag = False
            raise Exception("Exception in connecting to the server ")
        except BaseException as error:
            raise Exception(error)
        except socket.timeout as error:
            raise Exception("Connection timed out", error)
        else:
            result_flag = True
        return result_flag

    def run_command(self, *commands):
        """
            This function execute the shell commands over on terminals on connected remote host machine
            :param commands: parameter have shell commands single or multiple
            :return: return true if executed else false
        """
        result_flag = True
        try:
            if self.connect(self.ip, self.username, self.password):
                for command in commands:
                    print('Executing command')
                    stdin, stdout, stderr = self.client.exec_command(command)
                    self.ssh_output = stdout.readlines()
                    self.ssh_error = stderr.read()
                    for line in self.ssh_output:
                        print(line.rstrip())
                    if self.ssh_error:
                        print("Problem occurred while running command:" + command +
                              " The error is " + str(self.ssh_error))
                        raise ValueError("Connection refused")
                    else:
                        print("Command execution completed successfully", command)
            else:
                print("Could not establish SSH connection")
                result_flag = False
        except socket.timeout as e:
            print("Command timed out.", commands, e)
            self.client.close()
            result_flag = False
        except paramiko.SSHException:
            print("Failed to execute the command!", commands)
            self.client.close()
            result_flag = False
        return result_flag