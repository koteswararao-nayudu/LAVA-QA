#!/bin/bash

echo "Firmware binary path is $1"
firmware_path=$(readlink -f $1)
echo "Firmware relative path is $firmware_path"
cd /lab-nfs/scratch/jude/board
source EVB/env.sh
OCD_ARM_INIT=0 FLASH_EN=1 /lab-nfs/tools/OpenOCD/openocd_rpi -f /lab-nfs/scratch/jude/board/EVB/common/openocd_r2_v2.cfg  &

sleep 5
/lab-nfs/lava/1.exp $firmware_path
sleep 5
